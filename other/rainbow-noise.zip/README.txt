A Pen created at CodePen.io. You can find this one at http://codepen.io/rglazebrook/pen/dGygXY.

 A potential starting point for future projects. Saving simplex noise as r/g/b gives me 3 numbers to work with. Scaling the noise up provides lots of gradient space at not a lot of processing cost.