A Pen created at CodePen.io. You can find this one at http://codepen.io/joeldom/pen/jWPdjx.

 

Forked from [Shingo Suzuki](http://codepen.io/shingo2000/)'s Pen [Rainbow Effect](http://codepen.io/shingo2000/pen/xwLMXE/).