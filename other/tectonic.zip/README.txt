A Pen created at CodePen.io. You can find this one at http://codepen.io/cathbailh/pen/VewxQJ.

 Forked from [Charlotte Dann](http://codepen.io/pouretrebelle/)'s Pen [Blobs](http://codepen.io/pouretrebelle/pen/oXxbxp/)

AND

 from [Tiffany Rayside](http://codepen.io/tmrDevelops/)'s Pen [Dragon Ball](http://codepen.io/tmrDevelops/pen/Bjawxr/).