This code goes along with the screencast [Fetching Data with AJAX](https://www.youtube.com/watch?v=9E9qtNg5V2I).
