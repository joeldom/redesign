Make HTML structure explicit
