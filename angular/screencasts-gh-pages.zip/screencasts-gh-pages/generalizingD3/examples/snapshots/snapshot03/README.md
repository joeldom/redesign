Implement Single Var Pattern

As a best practice.

Avoids scope confusion with [variable hoisting](http://www.adequatelygood.com/JavaScript-Scoping-and-Hoisting.html).
