Split into HTML, CSS and JS files

* [`type="text/css"` not necessary in HTML5](http://stackoverflow.com/questions/7715953/do-we-need-type-text-css-for-link-in-html5)
* Reveals [abbreviated HTML structure](http://stackoverflow.com/questions/5641997/is-it-necessary-to-write-head-body-and-html-tags) of D3 example
