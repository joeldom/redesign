Split up Y axis group creation and configuration
