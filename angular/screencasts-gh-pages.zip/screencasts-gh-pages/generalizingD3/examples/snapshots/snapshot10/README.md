Isolate hard-coded visualization size
