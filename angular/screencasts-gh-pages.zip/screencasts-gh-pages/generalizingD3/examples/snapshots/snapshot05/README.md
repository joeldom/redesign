Split bar chart and main program
