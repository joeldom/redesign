Split up SVG and Group creation and configuration

Separates things that happen once (e.g. SVG and G element creation) from things that may happen many times (e.g. setting size and transform).
