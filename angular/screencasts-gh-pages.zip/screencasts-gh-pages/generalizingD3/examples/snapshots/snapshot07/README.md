Split up X axis group creation and configuration
