Split up enter and update for bars
