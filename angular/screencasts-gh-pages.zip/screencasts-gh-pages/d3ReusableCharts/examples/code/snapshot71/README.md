Introducing the Iris data set

 * Each entry is an iris flower
 * From [UCI Machine Learning Repository](https://archive.ics.uci.edu/ml/datasets/Iris)
 * Extent computed using D3 [min](https://github.com/mbostock/d3/wiki/Arrays#d3_min) and [max](https://github.com/mbostock/d3/wiki/Arrays#d3_max)
