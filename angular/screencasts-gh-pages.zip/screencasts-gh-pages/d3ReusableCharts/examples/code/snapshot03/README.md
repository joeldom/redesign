Default SVG size

 * Unpredictable, browser-dependent
 * Better to specify SVG width, height
