stroke and width

 * apply to circles also
