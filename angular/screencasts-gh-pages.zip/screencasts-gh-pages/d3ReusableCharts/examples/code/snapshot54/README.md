rangePoints

* See [D3 rangePoints documentation](https://github.com/mbostock/d3/wiki/Ordinal-Scales#ordinal_rangePoints)
