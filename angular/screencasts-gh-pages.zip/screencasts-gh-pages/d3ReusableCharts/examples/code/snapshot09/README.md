Hex color codes

 * Most common color representation
 * Used in [D3 Color Scales](https://github.com/mbostock/d3/wiki/Ordinal-Scales#category10)
 * [Color picker](http://www.colorpicker.com/)
