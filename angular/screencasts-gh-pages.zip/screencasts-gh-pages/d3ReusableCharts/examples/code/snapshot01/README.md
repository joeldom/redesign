Hello HTML

 * Bare bones [HTML5 document](http://www.w3.org/TR/html5/document-metadata.html)
 * Taken from [JSBin starter code](http://jsbin.com/)
