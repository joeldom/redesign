Transparency with rgba()

 * The "a" [rgba](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value#rgba()) stands for alpha (transparency)
 * "a" varies between 0 and 1
