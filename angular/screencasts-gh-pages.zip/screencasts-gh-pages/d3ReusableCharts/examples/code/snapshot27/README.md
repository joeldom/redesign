Styling SVG Text with CSS

 * using [the "em" unit](http://stackoverflow.com/questions/609517/why-em-instead-of-px)
