Using enter for static properties
