cx and cy

 * (x, y) pixel coordinates of the center of the circle
