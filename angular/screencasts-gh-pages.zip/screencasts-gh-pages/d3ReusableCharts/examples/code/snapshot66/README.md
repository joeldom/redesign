Exit

 * Completes the D3 pattern
 * Enter, Update, Exit
 * Correctly handles changing data
