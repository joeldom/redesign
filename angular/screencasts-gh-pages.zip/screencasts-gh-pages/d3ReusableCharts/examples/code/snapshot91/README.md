using variables to define the margin
