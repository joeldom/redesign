Specifying SVG dimensions
