using extent

 * See [d3.extent documentation](https://github.com/mbostock/d3/wiki/Arrays#d3_extent)
