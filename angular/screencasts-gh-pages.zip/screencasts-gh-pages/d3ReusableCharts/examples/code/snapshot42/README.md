An array of objects

 * Typical data structure with D3
 * Represents tabular data
