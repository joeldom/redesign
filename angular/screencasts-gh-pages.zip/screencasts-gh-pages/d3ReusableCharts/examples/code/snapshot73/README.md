basic scatter plot
