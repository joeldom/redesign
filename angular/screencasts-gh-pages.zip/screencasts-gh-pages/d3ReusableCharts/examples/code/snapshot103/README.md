customizing axes

 * [space-delimited classes applies both](http://stackoverflow.com/questions/13808846/html-class-attribute-with-spaces-it-is-a-w3c-valid-class)
 * see also [D3 Tick Format example](http://bl.ocks.org/mbostock/9764126)
 * docs: [tickFormat](https://github.com/mbostock/d3/wiki/SVG-Axes#tickFormat), [d3.format](https://github.com/mbostock/d3/wiki/Formatting#d3_format)
