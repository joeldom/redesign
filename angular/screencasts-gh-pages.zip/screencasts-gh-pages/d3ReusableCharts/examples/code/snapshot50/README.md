D3 linear scale

 * See [D3 Quantitative Scales documentation](https://github.com/mbostock/d3/wiki/Quantitative-Scales)
