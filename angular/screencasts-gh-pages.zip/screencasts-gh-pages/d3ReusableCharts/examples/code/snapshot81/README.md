Using fill, tweaking parameters
