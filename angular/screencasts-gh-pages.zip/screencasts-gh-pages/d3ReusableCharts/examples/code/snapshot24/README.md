pseudo bar chart
