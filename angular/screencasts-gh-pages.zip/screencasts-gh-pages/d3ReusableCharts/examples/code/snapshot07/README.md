rgb() color syntax

 * (red, green, blue)
 * Each varies from 0 - 255 (8 bits)
