inverting the Y range

 * this is the correct behavior
 * remember (0, 0) is the upper left corner
