tweaking the visualization

 * 100,000 people per pixel
