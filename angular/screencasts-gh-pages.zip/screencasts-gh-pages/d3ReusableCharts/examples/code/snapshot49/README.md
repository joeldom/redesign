Parsing CSV data

 * using +
