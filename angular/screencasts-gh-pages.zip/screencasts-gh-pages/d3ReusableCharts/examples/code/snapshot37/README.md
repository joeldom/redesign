Concatenation of number strings
