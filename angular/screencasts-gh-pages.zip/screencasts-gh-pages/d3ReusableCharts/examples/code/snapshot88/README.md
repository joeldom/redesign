sizing the inner visualization
