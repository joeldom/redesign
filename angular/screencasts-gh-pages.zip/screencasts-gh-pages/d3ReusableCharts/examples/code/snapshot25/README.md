pseudo line chart
