using a margin object

 * This is the [D3 Margin Convention](http://bl.ocks.org/mbostock/3019563)
