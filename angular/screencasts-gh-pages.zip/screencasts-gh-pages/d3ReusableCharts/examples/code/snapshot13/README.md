Drawing a [circle](https://developer.mozilla.org/en-US/docs/Web/SVG/Element/circle)

 * "r" stands for "radius", in pixels
