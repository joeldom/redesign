using variables for X and Y columns
