population as sqrt size

 * Using [D3 square root scale](https://github.com/mbostock/d3/wiki/Quantitative-Scales#sqrt)
 * Consider the [area of a circle](https://www.google.com/search?q=area+of+a+circle&oq=area+of+a+circle)
 * Still not quite right.
 * How many people per pixel?
