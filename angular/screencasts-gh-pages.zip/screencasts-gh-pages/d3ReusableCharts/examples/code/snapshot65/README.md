The need for exit
