the g element

 * ["g"](https://developer.mozilla.org/en-US/docs/Web/SVG/Element/g) stands for "group"
 * group [transform](https://developer.mozilla.org/en-US/docs/Web/SVG/Attribute/transform) applies to child elements
