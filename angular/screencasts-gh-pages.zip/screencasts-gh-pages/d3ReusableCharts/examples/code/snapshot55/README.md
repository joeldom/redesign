rangeRoundPoints

 * Rounds values up
