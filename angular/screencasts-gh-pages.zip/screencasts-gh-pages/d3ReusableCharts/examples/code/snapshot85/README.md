population as logarithmic size

 * Not quite right.
 * How many people per pixel?
