Adding color

 * Uses [fill](https://developer.mozilla.org/en-US/docs/Web/SVG/Tutorial/Fills_and_Strokes)
 * This accepts [CSS Color Strings](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value)
