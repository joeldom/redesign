Rendering an array of objects
