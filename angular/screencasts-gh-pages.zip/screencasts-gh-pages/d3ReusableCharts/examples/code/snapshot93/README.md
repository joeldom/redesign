specifying number of people per pixel

 * Exactly 1 million people per pixel.
 * Algebraic manipulation of [example 87](#87)
