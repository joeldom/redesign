D3 method chaining

 * A common pattern in D3
