Using setTimeout
