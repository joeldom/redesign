population as linear size
