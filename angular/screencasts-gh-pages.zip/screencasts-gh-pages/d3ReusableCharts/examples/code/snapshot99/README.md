drawing a proper line
