Drawing transparent rings
