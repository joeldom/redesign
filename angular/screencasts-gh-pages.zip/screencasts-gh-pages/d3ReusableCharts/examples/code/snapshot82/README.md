Population vs. GDP

 * GDP = [Gross Domestic Product](http://en.wikipedia.org/wiki/Gross_domestic_product)
 * From [github.com/curran/data](https://github.com/curran/data/tree/gh-pages/integrated)
