visualizing temperature in San Francisco

 * From [Data Canvas - Sense Your City](http://bl.ocks.org/curran/19d42e98ce25291eb45d)
 * Here are [data extracts](https://github.com/curran/data/tree/gh-pages/senseYourCity)
 * Better suited as lines.
