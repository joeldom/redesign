using SVG paths

 * [Domain specific language for paths](https://developer.mozilla.org/en-US/docs/Web/SVG/Tutorial/Paths)
 * M = Move to
 * L = Line to
