font fill and stroke
