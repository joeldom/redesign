Drawing outlines with stroke

 * [stroke](https://developer.mozilla.org/en-US/docs/Web/SVG/Tutorial/Fills_and_Strokes) also accepts CSS color strings
