D3 ordinal scale

 * See [D3 Ordinal Scales documentation](https://github.com/mbostock/d3/wiki/Ordinal-Scales)
