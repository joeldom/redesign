Adding a color column

 * Using [d3.scale.category10](https://github.com/mbostock/d3/wiki/Ordinal-Scales#category10)
