Parsing strings with +

 * Found in [D3 Examples](http://bl.ocks.org/mbostock/3885304)
