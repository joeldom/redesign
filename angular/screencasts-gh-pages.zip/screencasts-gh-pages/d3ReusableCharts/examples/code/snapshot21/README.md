closing a path

 * Z = Close path
