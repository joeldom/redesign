Rendering a parsed CSV file
