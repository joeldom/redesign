D3 getter setter functions

 * Typical in D3
 * See also [Towards Reusable Charts](http://bost.ocks.org/mike/chart/)
