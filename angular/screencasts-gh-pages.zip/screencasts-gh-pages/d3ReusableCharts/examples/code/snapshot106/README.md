axes on a scatter plot
