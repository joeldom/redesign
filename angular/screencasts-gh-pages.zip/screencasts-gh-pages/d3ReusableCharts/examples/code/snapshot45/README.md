Functional forEach

 * "d" is a D3 convention
 * represents one "data element"
 * in [D3 Bar Chart](http://bl.ocks.org/mbostock/3885304)
