Hello SVG

 * Basic [Scalable Vector Graphics](http://en.wikipedia.org/wiki/Scalable_Vector_Graphics) example
 * Creates a [rectangle](https://developer.mozilla.org/en-US/docs/Web/SVG/Element/rect)
