Loading CSV data

 * Use D3 via [cdnjs](https://cdnjs.com/)
 * See [D3 CSV Documentation](https://github.com/mbostock/d3/wiki/CSV)
