population true to size

 * 1.08 million people per pixel
