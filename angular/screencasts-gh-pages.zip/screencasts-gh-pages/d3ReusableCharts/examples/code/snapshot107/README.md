axes on a line chart
