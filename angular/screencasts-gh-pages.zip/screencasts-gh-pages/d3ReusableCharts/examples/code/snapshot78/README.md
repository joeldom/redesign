Using CSS to color circles
