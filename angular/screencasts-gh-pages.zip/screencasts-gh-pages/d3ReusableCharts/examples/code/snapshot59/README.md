Passing the scale as a function
