constructing DOM elements with D3

 * D3 is essentially a [DOM](https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model) manipulation library
