JavaScript functions

 * arguments
 * return value
