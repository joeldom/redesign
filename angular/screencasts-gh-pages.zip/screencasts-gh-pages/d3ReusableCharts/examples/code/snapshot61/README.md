Enter handles added data only
