drawing several lines
