horizontal bars

 * can show more bar labels than vertical bars
 * swap (x, y), (width, height) throughout
