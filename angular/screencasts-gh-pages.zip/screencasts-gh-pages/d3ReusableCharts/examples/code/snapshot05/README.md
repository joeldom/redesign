Adding (x, y) coordinates

 * (0, 0) is in the upper left
