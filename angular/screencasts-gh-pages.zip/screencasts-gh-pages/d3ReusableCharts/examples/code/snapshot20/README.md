filling a path
