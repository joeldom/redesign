Enter does not update data
