translating the inner visualization

 * g means SVG Group
 * similar to [example 23](#/23)
