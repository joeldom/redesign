drawing a [line](https://developer.mozilla.org/en-US/docs/Web/SVG/Element/line)

 * From (x1, y1) to (x2, y2)
 * Fill does not apply to lines
