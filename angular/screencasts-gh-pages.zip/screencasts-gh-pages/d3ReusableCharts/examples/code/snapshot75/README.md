isolating configurable variables

 * outerWidth, outerHeight, circleRadius
