The D3 update phase
