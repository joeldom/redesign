Splitting data binding and enter

 * Great article on [Binding Data](http://alignedleft.com/tutorials/d3/binding-data) by Scott Murray
