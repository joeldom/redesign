Parsing strings with parseFloat
