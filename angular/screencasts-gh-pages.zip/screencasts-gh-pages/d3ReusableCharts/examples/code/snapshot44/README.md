Functions in variables

 * [Functions](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions) are first class objects in JS
