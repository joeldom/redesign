Controlling stroke width
