sizing taking translation into account
