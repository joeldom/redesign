basic bar chart

 * using [ordinal.rangeBands](https://github.com/mbostock/d3/wiki/Ordinal-Scales#ordinal_rangeBands)
 * see also [D3 Bar Chart example](http://bl.ocks.org/mbostock/3885304)
