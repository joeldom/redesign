The complete D3 pipeline

 * Uses [Enter](http://d3js.org/#enter-exit)
 * Typical D3 pattern
