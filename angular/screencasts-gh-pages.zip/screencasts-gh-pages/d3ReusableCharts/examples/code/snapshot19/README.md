drawing several lines with a path

 * Fill does apply to paths
 * It is turned off with `fill="none"`
