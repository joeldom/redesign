showing density with transparency

 * It's amazing what a dash of CSS can do.
