using d3.svg.line

 * See [d3.svg.line documentation](https://github.com/mbostock/d3/wiki/SVG-Shapes#line)
 * See also [D3 line chart example](http://bl.ocks.org/mbostock/3883245)
