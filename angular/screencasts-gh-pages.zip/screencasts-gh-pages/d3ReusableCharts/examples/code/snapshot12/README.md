Using fill="none"

 * A special value to turn off filling
