visualizing cities

 * 1 million people per pixel
 * shows 4,272 cities with population > 100,000
 * data from [GeoNames extract](https://github.com/curran/data/tree/gh-pages/geonames)
