bar padding
