Applying CSS to circles
