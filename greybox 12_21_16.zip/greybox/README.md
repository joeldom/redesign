16-redesign
===========

Complete overhaul of the theme that is currently working on my site.

The idea is to create a custom CSS framework that can be extensible and completely custom to accommodate any image or file type.
